import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime
import json
import os
from PIL import Image, ImageTk
import sys
from tkinter import font
from PIL import Image, ImageTk
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import pandas as pd

class VentanaInicio:
    def __init__(self, raiz):
        self.raiz = raiz
        self.raiz.title("Inicio")
        self.raiz.configure(bg="#FEF3E2")  # Fondo azul claro
        self.raiz.iconbitmap("Interfaz//IconoAPP.ico")
        ancho_ventana = 450
        alto_ventana = 680
        # Obtener el tamaño de la pantalla
        ancho_pantalla = self.raiz.winfo_screenwidth()
        alto_pantalla = self.raiz.winfo_screenheight()

        # Calcular la posición centrada
        pos_x = int((ancho_pantalla - ancho_ventana) / 2)
        pos_y = int((alto_pantalla - alto_ventana) / 2)
        self.raiz.resizable(0, 0)

        # Establecer la geometría de la ventana con la posición centrada
        self.raiz.geometry(f"{ancho_ventana}x{alto_ventana}+{pos_x}+{pos_y}")

        # Frame superior para la imagen (60% de la ventana)
        self.frame_superior = tk.Frame(self.raiz, bg="#FEF3E2", height=384)  # 40% de 640px
        self.frame_superior.pack(fill="x", pady=(20, 0))
        self.frame_superior.pack_propagate(False)  # Mantener el tamaño fijo
        
        # Cargar imagen (reemplaza con tu propia imagen)
        try:
            # Intenta cargar la imagen, si no existe muestra un mensaje
            imagen = Image.open("Interfaz/Bienvenida.jpg") 
            imagen = imagen.resize((450, 390), Image.LANCZOS)
            self.imagen_tk = ImageTk.PhotoImage(imagen)
            self.img_label = tk.Label(self.frame_superior, image=self.imagen_tk, bg="#FEF3E2")
            self.img_label.pack(expand=True)
        except Exception as e:
            self.img_label = tk.Label(self.frame_superior, 
                                    text="Logo App", 
                                    bg="#FEF3E2", 
                                    fg="#182C2B",
                                    font=("Helvetica", 24, "bold"))
            self.img_label.pack(expand=True)
            print(f"Error cargando la imagen: {e}")

        # Frame inferior (40% de la ventana)
        self.frame_inferior = tk.Frame(self.raiz, bg="#ffffff", height=256)
        self.frame_inferior.pack(fill="both", expand=True)
        
        # Contenido del frame inferior
        self.titulo = tk.Label(
            self.frame_inferior, 
            text="Bienvenido", 
            font=("Helvetica", 14, "bold"), 
            bg="white",
            fg="#182C2B"
        )
        self.titulo.pack(pady=(40, 10))
        
        self.subtitulo = tk.Label(
            self.frame_inferior,
            text="Juntos reforestamos esperanza,\n un árbol a la vez.",
            font=("Helvetica", 10),
            bg="white",
            fg="#7f8c8d",
            justify="center"
        )
        self.subtitulo.pack(pady=(0, 30))

        
        # Botón con estilo moderno
        self.boton = tk.Button(
            self.frame_inferior,
            text="Comenzar",
            font=("Montserrat", 12, "bold"),
            bg="#182C2B",
            fg="white",
            padx=15,
            pady=5,
            borderwidth=0,
            activebackground="#456A54",
            command=self.abrir_menu_principal
        )
        self.boton.pack(pady=20)
        
        # Efecto hover para el botón
        self.boton.bind("<Enter>", lambda e: self.boton.config(bg="#456A54"))
        self.boton.bind("<Leave>", lambda e: self.boton.config(bg="#456A54"))
    
    def abrir_menu_principal(self):
        self.raiz.destroy()  # Cierra esta ventana
        nueva_ventana = tk.Tk()
        from Reforestacion import VentanaPrincipal  # Importa clase VentanaPrincipal
        VentanaPrincipal(nueva_ventana)
        nueva_ventana.mainloop()

# Ejecutar como pantalla inicial
if __name__ == "__main__":
    raiz = tk.Tk()
    app = VentanaInicio(raiz)
    raiz.mainloop()

class VentanaPrincipal:
    def __init__(self, raiz):
        self.raiz = raiz
        self.raiz.title("Sistema de Gestión de Reforestación")
        raiz.configure(bg="#FEF3E2")
        raiz.iconbitmap("Interfaz//IconoAPP.ico")
        ancho_ventana = 450
        alto_ventana = 680
        # Obtener el tamaño de la pantalla
        ancho_pantalla = raiz.winfo_screenwidth()
        alto_pantalla = raiz.winfo_screenheight()

        # Calcular la posición centrada
        pos_x = int((ancho_pantalla - ancho_ventana) / 2)
        pos_y = int((alto_pantalla - alto_ventana) / 2)
        raiz.resizable(0, 0)

        # Establecer la geometría de la ventana con la posición centrada
        raiz.geometry(f"{ancho_ventana}x{alto_ventana}+{pos_x}+{pos_y}")

        # Encabezado "Menu"
        encabezado = ttk.Label(raiz, text="Menu", foreground="#182C2B", font=('Helvetica', 16, 'bold'), background="#FEF3E2")
        encabezado.pack(pady=(40,20))
        
        # Cargar las imágenes (asegúrate de que las rutas de las imágenes sean correctas)
        try:
            self.imagen_registro = tk.PhotoImage(file="Interfaz//VentanaPrincipal//editar1.png").subsample(1, 1)
            self.imagen_busqueda = tk.PhotoImage(file="Interfaz//VentanaPrincipal//lupa.png").subsample(1, 1)
            self.imagen_reportes = tk.PhotoImage(file="Interfaz//VentanaPrincipal//informe.png").subsample(1, 1)
            self.imagen_analisis = tk.PhotoImage(file="Interfaz//VentanaPrincipal//analisis1.png").subsample(1, 1)
            self.imagen_guia = tk.PhotoImage(file="Interfaz//VentanaPrincipal//plantar.png").subsample(1, 1)  
        except tk.TclError as e:
            messagebox.showerror("Error", f"No se pudieron cargar las imágenes: {e}")
            return
        
        # Crear un estilo personalizado para los botones
        estilo = ttk.Style()
        estilo.configure('EstiloBoton.TButton', 
                         font=('Helvetica', 12), 
                         padding=10, 
                         background='white', 
                         foreground='#182C2B',
                         borderwidth=2,
                         relief="flat")
        
        #frame para los botones 
        frame = tk.Frame(raiz, width=350, height=500)
        frame.pack(fill=tk.BOTH, expand=True)

        # Cargar imagen de fondo del frame
        try:
            self.imagen_fondo_frame = Image.open("Interfaz//VentanaPrincipal//2menu.png")
            self.imagen_fondo_frame = self.imagen_fondo_frame.resize((450, 612), Image.LANCZOS)
            self.tk_imagen_fondo_frame = ImageTk.PhotoImage(self.imagen_fondo_frame)

            # Imagen como fondo del frame
            fondo_label = tk.Label(frame, image=self.tk_imagen_fondo_frame)
            fondo_label.place(x=0, y=0, relwidth=1, relheight=1)
        except Exception as e:
            print(f"Error al cargar fondo del frame: {e}")
        
        # Botón de Registro de Árboles con imagen y texto al lado
        self.boton_registro = ttk.Button(frame, text="  Registro de Árboles", command=self.abrir_ventana_registro, 
                                        image=self.imagen_registro, compound=tk.LEFT, style='EstiloBoton.TButton')
        self.boton_registro.pack(fill=tk.X, pady=(80, 1), padx=10)
        
        # Botón de Búsqueda con imagen y texto al lado
        self.boton_busqueda = ttk.Button(frame, text="  Búsqueda                ", command=self.abrir_ventana_busqueda, 
                                        image=self.imagen_busqueda, compound=tk.LEFT, style='EstiloBoton.TButton')
        self.boton_busqueda.pack(fill=tk.X, pady=1, padx=10)
        
        # Botón de Reportes con imagen y texto al lado
        self.boton_reportes = ttk.Button(frame, text="  Reportes                 ", command=self.abrir_ventana_reportes, 
                                        image=self.imagen_reportes, compound=tk.LEFT, style='EstiloBoton.TButton')
        self.boton_reportes.pack(fill=tk.X, pady=1, padx=10)
        
        # Botón de Análisis de Datos con imagen y texto al lado
        self.boton_analisis = ttk.Button(frame, text="  Análisis de Datos  ", command=self.abrir_ventana_analisis, 
                                        image=self.imagen_analisis, compound=tk.LEFT, style='EstiloBoton.TButton')
        self.boton_analisis.pack(fill=tk.X, pady=1, padx=10)

        # Botón de Guía de Campo con imagen y texto al lado
        self.boton_guia = ttk.Button(frame, text="  Guía de Campo       ", command=self.abrir_ventana_guia, 
                                    image=self.imagen_guia, compound=tk.LEFT, style='EstiloBoton.TButton')
        self.boton_guia.pack(fill=tk.X, pady=1, padx=10)
    
    def abrir_ventana_registro(self):
        self.raiz.destroy() 
        ventana_registro = tk.Tk()  
        VentanaRegistroArboles(ventana_registro)
        ventana_registro.mainloop()

    def abrir_ventana_busqueda(self):
        self.raiz.destroy() 
        ventana_busqueda = tk.Tk()  
        VentanaBusqueda(ventana_busqueda)
        ventana_busqueda.mainloop()
        
    
    def abrir_ventana_reportes(self):
        self.raiz.destroy()  
        nueva_ventana = tk.Tk() 
        VentanaReportes(nueva_ventana)
        nueva_ventana.mainloop()
    
    def abrir_ventana_analisis(self):
        self.raiz.destroy() 
        root = tk.Tk()
        app = VentanaAnalisisDatos(root)
        root.mainloop()

    def abrir_ventana_guia(self):
        self.raiz.destroy() 
        ventana_guia = tk.Tk()  
        VentanaGuiaCampo(ventana_guia)
        ventana_guia.mainloop()

class VentanaRegistroArboles:
    def __init__(self, raiz):
        self.raiz = raiz
        self.raiz.title("Registro de Árboles")
        self.raiz.configure(bg="#FFFFFF")
        self.raiz.iconbitmap("Interfaz//IconoAPP.ico")

        ancho_ventana = 450
        alto_ventana = 680

        # Obtener el tamaño de la pantalla
        ancho_pantalla = self.raiz.winfo_screenwidth()
        alto_pantalla = self.raiz.winfo_screenheight()

        # Calcular la posición centrada
        pos_x = int((ancho_pantalla - ancho_ventana) / 2)
        pos_y = int((alto_pantalla - alto_ventana) / 2)

        # Establecer la geometría de la ventana con la posición centrada
        self.raiz.geometry(f"{ancho_ventana}x{alto_ventana}+{pos_x}+{pos_y}")

        # No se puede redimensionar la ventana
        self.raiz.resizable(0, 0)

        # Configurar estilo
        estilo = ttk.Style()
        estilo.theme_use('clam')  # Necesario para personalización
        estilo.configure("TFrame", background="#FEF3E2")
        estilo.configure("TLabel", background="white", font=("Arial", 10))
        
        # Frame superior para el botón de regresar
        frame_superior = ttk.Frame(raiz, height=30, width=350, style="TLabel")
        frame_superior.pack(fill="x", padx=10, pady=(10, 0))
        frame_superior.pack_propagate(False)
        
        # Botón de Regresar al Menú
        self.boton_regresar = tk.Button(
            frame_superior,
            text="<   Regresar",
            bg="white",
            fg="#577F67",
            command=self.regresar_al_menu,
            borderwidth=0,
            highlightthickness=0,
            font=("Montserrat", 12)
        )
        self.boton_regresar.pack(side="left", padx=5)

        # Frame para la imagen superior (reducido para dejar espacio al nuevo campo)
        frame_imagen = ttk.Frame(raiz, height=300, width=300, style="TLabel")
        frame_imagen.pack(fill="x", padx=10, pady=(0, 10))
        frame_imagen.pack_propagate(False)
        
        try:
            self.imagen_original = Image.open("Interfaz//VentanaRegistroArboles//agregar.png")
            self.imagen_original = self.imagen_original.resize((275, 320), Image.LANCZOS)  # Reducido de 325 a 250
            self.imagen_tk = ImageTk.PhotoImage(self.imagen_original)
            self.label_imagen = ttk.Label(frame_imagen, image=self.imagen_tk)
            self.label_imagen.pack(expand=True)
        except Exception as e:
            self.label_imagen = ttk.Label(frame_imagen, 
                                        text="Imagen no encontrada\n(Interfaz//VentanaRegistroArboles//agregar.png)", 
                                        background="#E8F5E9")
            self.label_imagen.pack(expand=True, fill="both")
            print(f"Error al cargar la imagen: {e}", file=sys.stderr)

        # Frame inferior para los datos del formulario
        frame_datos = ttk.Frame(raiz, style="TFrame")
        frame_datos.pack(fill="both", expand=True)

        # Imagen de fondo para el frame_datos
        try:
            self.imagen_fondo_formulario = Image.open("Interfaz//VentanaRegistroArboles//frame2.png")
            self.imagen_fondo_formulario = self.imagen_fondo_formulario.resize((450, 350), Image.LANCZOS)
            self.tk_imagen_fondo = ImageTk.PhotoImage(self.imagen_fondo_formulario)
            self.fondo_label = tk.Label(frame_datos, image=self.tk_imagen_fondo)
            self.fondo_label.place(relx=0, rely=0, relwidth=1, relheight=1)
        except Exception as e:
            print(f"Error cargando fondo del formulario: {e}", file=sys.stderr)

        # Configurar estilos para los campos
        estilo.configure("EstiloEtiqueta.TLabel", 
                       background="#FEF3E2", 
                       foreground="#182C2B", 
                       font=("Montserrat", 12))
        
        estilo.configure("EstiloEntrada.TEntry",
                       fieldbackground="#FEF3E2",
                       foreground="#777777",  # Color gris para el placeholder
                       font=("Montserrat", 25),
                       padding=9)

        # Campos del formulario con estilos aplicados
        ttk.Label(frame_datos, text="Especie:", style="EstiloEtiqueta.TLabel").grid(row=0, column=0, padx=20, pady=(27, 5), sticky="w")
        self.entrada_especie = ttk.Entry(frame_datos, style="EstiloEntrada.TEntry")
        self.entrada_especie.grid(row=0, column=1, padx=20, pady=(27, 5), sticky="ew")
        
        ttk.Label(frame_datos, text="Ubicación:", style="EstiloEtiqueta.TLabel").grid(row=1, column=0, padx=20, pady=5, sticky="w")
        self.entrada_ubicacion = ttk.Entry(frame_datos, style="EstiloEntrada.TEntry")
        self.entrada_ubicacion.grid(row=1, column=1, padx=20, pady=5, sticky="ew")
        
        ttk.Label(frame_datos, text="Fecha de Plantación:", style="EstiloEtiqueta.TLabel").grid(row=2, column=0, padx=20, pady=5, sticky="w")
        self.entrada_fecha = ttk.Entry(frame_datos, style="EstiloEntrada.TEntry")
        self.entrada_fecha.grid(row=2, column=1, padx=20, pady=5, sticky="ew")

        ##
        # Agregar texto de ejemplo (placeholder)
        self.entrada_fecha.insert(0, "DD/MM/AAAA")  # Texto de ejemplo
        self.entrada_fecha.bind("<FocusIn>", self.limpiar_placeholder_fecha)  # Limpiar al hacer clic
        self.entrada_fecha.bind("<FocusOut>", self.verificar_placeholder_fecha)  # Restaurar si está vacío
        
        # Nuevo campo para la imagen (añadido en el espacio ganado al reducir la imagen superior)
        ttk.Label(frame_datos, text="Imagen:", style="EstiloEtiqueta.TLabel").grid(row=3, column=0, padx=20, pady=5, sticky="w")
        
        # Frame para los botones de imagen
        frame_imagen_arbol = ttk.Frame(frame_datos, style="TFrame")
        frame_imagen_arbol.grid(row=3, column=1, padx=20, pady=5, sticky="ew")
        
        # Botón para seleccionar imagen (más compacto)
        self.boton_seleccionar_imagen = tk.Button(
            frame_imagen_arbol,
            text="Seleccionar",
            bg="#FEF3E2",
            fg="#182C2B",
            font=("Montserrat", 12),
            command=self.seleccionar_imagen,
            borderwidth=0,
            highlightthickness=0,
            padx=5
        )
        self.boton_seleccionar_imagen.pack(side="left")
        
        # Etiqueta para mostrar el nombre del archivo seleccionado (más compacta)
        self.etiqueta_imagen_seleccionada = ttk.Label(
            frame_imagen_arbol, 
            text="Ninguna", 
            style="EstiloEtiqueta.TLabel",
            font=("Montserrat", 12),
            wraplength=150  # Para que el texto largo se ajuste
        )
        self.etiqueta_imagen_seleccionada.pack(side="left", padx=5)
        
        # Variable para almacenar la ruta de la imagen
        self.ruta_imagen = None

        # Frame para botones
        frame_botones = ttk.Frame(frame_datos, style="TFrame")
        frame_botones.grid(row=6, column=0, columnspan=2, pady=(35, 10))  
        
        # Cargar imagen del botón Registrar
        try:
            self.img_registrar = Image.open("Interfaz//VentanaRegistroArboles//mas.png")  
            self.img_registrar = self.img_registrar.resize((25, 25), Image.LANCZOS)
            self.tk_img_registrar = ImageTk.PhotoImage(self.img_registrar)
        except Exception as e:
            print(f"Error cargando imagen del botón Registrar: {e}")
            self.tk_img_registrar = None

        # Botón Registrar MEJORADO
        self.boton_registrar = tk.Button(
            frame_botones,
            text="  Registrar mi árbol",
            image=self.tk_img_registrar,
            compound="left",
            bg="#FEF3E2",
            fg="#182C2B",
            font=("Montserrat", 12, "bold"),
            command=self.registrar_datos_arbol,
            borderwidth=0,
            highlightthickness=0,
            activebackground="#456A54",
            activeforeground="white",
            padx=15,
            pady=5
        )
        self.boton_registrar.pack()

        frame_datos.columnconfigure(1, weight=1)

    def limpiar_placeholder_fecha(self, event):
        """Limpia el placeholder cuando el campo recibe foco"""
        if self.entrada_fecha.get() == "DD/MM/AAAA":
            self.entrada_fecha.delete(0, tk.END)
            self.entrada_fecha.configure(foreground="#182C2B")  # Restaurar color normal

    def verificar_placeholder_fecha(self, event):
        """Vuelve a mostrar el placeholder si el campo está vacío"""
        if not self.entrada_fecha.get():
            self.entrada_fecha.insert(0, "DD/MM/AAAA")
            self.entrada_fecha.configure(foreground="#777777")  # Color más claro para el placeholder

    def seleccionar_imagen(self):
        from tkinter import filedialog
        filetypes = (
            ('Imágenes', '*.jpg *.jpeg *.png'),
            ('Todos los archivos', '*.*')
        )
        
        filename = filedialog.askopenfilename(
            title="Seleccionar imagen del árbol",
            filetypes=filetypes
        )
        
        if filename:
            self.ruta_imagen = filename
            nombre_archivo = os.path.basename(filename)
            # Mostrar solo los primeros 10 caracteres + extensión si el nombre es muy largo
            if len(nombre_archivo) > 10:
                nombre_mostrar = f"{nombre_archivo[:10]}...{nombre_archivo[-4:]}"
            else:
                nombre_mostrar = nombre_archivo
            self.etiqueta_imagen_seleccionada.config(text=nombre_mostrar)

    def validar_fecha(self, fecha_str):
        try:
            datetime.strptime(fecha_str, '%d/%m/%Y')
            return True
        except ValueError:
            return False

    def registrar_datos_arbol(self):
        especie = self.entrada_especie.get().strip()
        ubicacion = self.entrada_ubicacion.get().strip()
        fecha = self.entrada_fecha.get().strip()
        
        if not all([especie, ubicacion, fecha]):
            messagebox.showerror("Error", "Todos los campos son obligatorios")
            return
            
        if not self.validar_fecha(fecha):
            messagebox.showerror("Error", "Formato de fecha incorrecto. Use DD/MM/AAAA")
            return
            
        # Crear directorio para imágenes si no existe
        directorio_imagenes = os.path.join(os.path.dirname(os.path.abspath(__file__)), "imagenes_arboles")
        os.makedirs(directorio_imagenes, exist_ok=True)
        
        # Copiar la imagen seleccionada al directorio del proyecto
        nombre_imagen = None
        if self.ruta_imagen:
            try:
                import shutil
                nombre_imagen = f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{os.path.basename(self.ruta_imagen)}"
                destino_imagen = os.path.join(directorio_imagenes, nombre_imagen)
                shutil.copy2(self.ruta_imagen, destino_imagen)
            except Exception as e:
                messagebox.showwarning("Advertencia", f"No se pudo guardar la imagen: {str(e)}")
                nombre_imagen = None
        
        arbol = {
            "especie": especie,
            "ubicacion": ubicacion,
            "fecha_plantacion": fecha,
            "fecha_registro": datetime.now().strftime("%d/%m/%Y %H:%M:%S"),
            "imagen": nombre_imagen  # Guardamos solo el nombre del archivo
        }
        
        try:
            directorio = os.path.dirname(os.path.abspath(__file__))
            archivo_json = os.path.join(directorio, "Base_de_Datos//arboles.json")
            
            datos = []
            if os.path.exists(archivo_json):
                with open(archivo_json, 'r', encoding='utf-8') as f:
                    try:
                        datos = json.load(f)
                        if not isinstance(datos, list):
                            datos = []
                    except json.JSONDecodeError:
                        datos = []
            
            datos.append(arbol)
            
            with open(archivo_json, 'w', encoding='utf-8') as f:
                json.dump(datos, f, indent=4, ensure_ascii=False)
                
            messagebox.showinfo("Tu árbol ha sido registrado con éxito.", "\n🌱 ¡Gracias por contribuir a un futuro más verde!")
            self.limpiar_formulario()
            
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo guardar: {str(e)}")
            print(f"Error al guardar: {e}", file=sys.stderr)

    def limpiar_formulario(self):
        self.entrada_especie.delete(0, tk.END)
        self.entrada_ubicacion.delete(0, tk.END)
        self.entrada_fecha.delete(0, tk.END)
        self.etiqueta_imagen_seleccionada.config(text="Ninguna")
        self.ruta_imagen = None

    def regresar_al_menu(self):
        self.raiz.destroy()
        nueva_ventana = tk.Tk()
        VentanaPrincipal(nueva_ventana)
        nueva_ventana.mainloop()

class VentanaBusqueda:
    def __init__(self, raiz): 
        self.raiz = raiz
        self.raiz.title("Búsqueda Avanzada")
        self.raiz.geometry("450x680")
        self.raiz.configure(bg="#FCF7F4")
        self.raiz.iconbitmap("Interfaz//IconoAPP.ico")

        ancho_ventana = 450
        alto_ventana = 680

        # Obtener el tamaño de la pantalla
        ancho_pantalla = self.raiz.winfo_screenwidth()
        alto_pantalla = self.raiz.winfo_screenheight()

        # Calcular la posición centrada
        pos_x = int((ancho_pantalla - ancho_ventana) / 2)
        pos_y = int((alto_pantalla - alto_ventana) / 2)

        # Establecer la geometría de la ventana con la posición centrada
        self.raiz.geometry(f"{ancho_ventana}x{alto_ventana}+{pos_x}+{pos_y}")

        # No se puede redimensionar la ventana
        self.raiz.resizable(0, 0)

        # Configurar estilo
        estilo = ttk.Style()
        estilo.theme_use('clam')
        estilo.configure("TFrame", background="#FCF7F4")
        estilo.configure("TLabel", background="#FCF7F4", font=("Arial", 10))
        
        # Frame superior solo para el botón de regresar (alineado a la izquierda)
        frame_boton_regresar = ttk.Frame(raiz, height=40, style="TLabel")
        frame_boton_regresar.pack(fill="x", padx=10, pady=(10, 0))
        
        # Botón de Regresar al Menú (estilo igual a VentanaGuiaCampo)
        self.boton_regresar = tk.Button(
            frame_boton_regresar,
            text="<   Regresar",
            bg="#FCF7F4",
            fg="#577F67",
            command=self.regresar_al_menu,
            borderwidth=0,
            highlightthickness=0,
            font=("Montserrat", 12)
        )
        self.boton_regresar.pack(side="left", padx=5, pady=(10))
        
        # Frame separado para el título (centrado)
        frame_titulo = ttk.Frame(raiz, height=60, style="TLabel")
        frame_titulo.pack(fill="x", padx=10, pady=(0, 10))
        
        # Título de la ventana
        ttk.Label(
            frame_titulo,
            text="Búsqueda de Árboles Registrados",
            font=("Montserrat", 14, "bold"),
            foreground="#182C2B",
            background="#FCF7F4"
        ).pack(expand=True)

        # Cargar imagen de fondo para los frames de árboles
        try:
            self.fondo_arbol_img = Image.open("Interfaz//VentanaBusqueda//guia2.png")
            self.fondo_arbol_img = self.fondo_arbol_img.resize((400, 300), Image.LANCZOS)
            self.fondo_arbol_tk = ImageTk.PhotoImage(self.fondo_arbol_img)
        except Exception as e:
            print(f"Error al cargar imagen de fondo: {e}")
            self.fondo_arbol_tk = None
        
        # Frame principal con scrollbar
        main_frame = ttk.Frame(raiz)
        main_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Canvas y scrollbar
        canvas = tk.Canvas(main_frame, bg="#FCF7F4", highlightthickness=0)
        scrollbar = ttk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas, bg="#FCF7F4")
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(
                scrollregion=canvas.bbox("all")
            )
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        # Frame de filtros
        frame_filtros = tk.Frame(scrollable_frame, bg="#FCF7F4")
        frame_filtros.pack(fill="x", pady=(0, 10))
        
        # Configurar estilo
        estilo = ttk.Style()
        estilo.configure("Filtros.TLabel", 
                       background="#FCF7F4", 
                       foreground="#182C2B", 
                       font=("Montserrat", 12))
        
        # Estilo normal para entradas
        estilo.configure("Filtros.TEntry",
                       fieldbackground="#FCF7F4",
                       foreground="#182C2B",
                       font=("Montserrat", 12),  
                       padding=5)  
        
        # Estilo para placeholder 
        estilo.configure("Placeholder.TEntry",
                       fieldbackground="#FCF7F4",
                       foreground="#777777",  # Color gris para el placeholder
                       font=("Montserrat", 12),
                       padding=5)
        
        # Filtro por especie
        ttk.Label(frame_filtros, text="Especie:", style="Filtros.TLabel").grid(row=0, column=0, padx=20, pady=(27, 5), sticky="w")
        self.entrada_especie = ttk.Entry(frame_filtros, style="Filtros.TEntry")
        self.entrada_especie.grid(row=0, column=1, padx=20, pady=(27, 5), sticky="ew")
        
        # Filtro por ubicación
        ttk.Label(frame_filtros, text="Ubicación:", style="Filtros.TLabel").grid(row=1, column=0, padx=20, pady=5, sticky="w")
        self.entrada_ubicacion = ttk.Entry(frame_filtros, style="Filtros.TEntry")
        self.entrada_ubicacion.grid(row=1, column=1, padx=20, pady=5, sticky="ew")
        
        # Filtro por fecha
        ttk.Label(frame_filtros, text="Fecha de Plantación:", style="Filtros.TLabel").grid(
            row=2, column=0, padx=20, pady=5, sticky="w")
        
        self.entrada_fecha = ttk.Entry(
            frame_filtros, 
            style="Placeholder.TEntry",  # Usar estilo de placeholder inicialmente
            width=15  # Ancho fijo en caracteres
        )
        self.entrada_fecha.grid(
            row=2, column=1, 
            padx=20, pady=5, 
            sticky="ew",
            ipady=3  # Padding interno vertical para mejor apariencia
        )
        
        # Configuración de columnas para mantener tamaño 
        frame_filtros.columnconfigure(1, weight=1, minsize=200)  # Ancho mínimo de 200px
        
        # Configurar el placeholder
        self.placeholder_text = "DD/MM/AAAA"
        self.entrada_fecha.insert(0, self.placeholder_text)
        self.entrada_fecha.bind("<FocusIn>", self.limpiar_placeholder_fecha)
        self.entrada_fecha.bind("<FocusOut>", self.verificar_placeholder_fecha)
        
        # Botones
        frame_botones = ttk.Frame(frame_filtros)
        frame_botones.grid(row=3, column=0, columnspan=2, pady=(10, 0))
        
        # Cargar imágenes para los botones 
        try:
            self.img_buscar = Image.open("Interfaz//VentanaBusqueda//buscar.png")  
            self.img_buscar = self.img_buscar.resize((35, 35), Image.LANCZOS)
            self.tk_img_buscar = ImageTk.PhotoImage(self.img_buscar)

            self.img_limpiar = Image.open("Interfaz//VentanaBusqueda//escoba.png")  
            self.img_limpiar = self.img_limpiar.resize((35, 35), Image.LANCZOS)
            self.tk_img_limpiar = ImageTk.PhotoImage(self.img_limpiar)
        except Exception as e:
            print(f"Error cargando imágenes de botones: {e}")
            self.tk_img_buscar = None
            self.tk_img_limpiar = None

        # Botón Buscar (
        self.boton_buscar = tk.Button(
            frame_botones,
            text="  Buscar árboles",
            image=self.tk_img_buscar,
            compound="left",
            bg="#FCF7F4",
            fg="#182C2B",
            font=("Montserrat", 12, "bold"),
            command=self.filtrar_resultados,
            borderwidth=0,
            highlightthickness=0,
            activebackground="#456A54",
            activeforeground="white",
            padx=15,
            pady=5
        )
        self.boton_buscar.pack(side="left", padx=5)

        # Botón Limpiar 
        self.boton_limpiar = tk.Button(
            frame_botones,
            text="  Limpiar filtros",
            image=self.tk_img_limpiar,
            compound="left",
            bg="#FCF7F4",
            fg="#182C2B",
            font=("Montserrat", 12, "bold"),
            command=self.limpiar_filtros,
            borderwidth=0,
            highlightthickness=0,
            activebackground="#EF9C66",  # Color naranja para el hover
            activeforeground="white",
            padx=15,
            pady=5
        )
        self.boton_limpiar.pack(side="left", padx=5)
        # Frame de resultados
        self.frame_resultados = tk.Frame(scrollable_frame, bg="#FCF7F4")
        self.frame_resultados.pack(fill="x", pady=(10, 0))
        
        # Cargar todos los datos inicialmente
        self.cargar_datos()
        self.limpiar_filtros()

    def limpiar_placeholder_fecha(self, event):
        """Limpia el placeholder cuando el campo recibe foco"""
        current_text = self.entrada_fecha.get()
        if current_text == self.placeholder_text:
            self.entrada_fecha.delete(0, tk.END)
            self.entrada_fecha.configure(style="Filtros.TEntry")  
        
    def verificar_placeholder_fecha(self, event):
        """Vuelve a mostrar el placeholder si el campo está vacío"""
        if not self.entrada_fecha.get():
            self.entrada_fecha.insert(0, self.placeholder_text)
            self.entrada_fecha.configure(style="Placeholder.TEntry")  

    def cargar_datos(self):
        try:
            directorio = os.path.dirname(os.path.abspath(__file__))
            archivo_json = os.path.join(directorio, "Base_de_Datos//arboles.json")

            # Verificamos si el archivo existe
            if not os.path.exists(archivo_json):
                self.datos = []  # Si no existe, inicializamos como lista vacía
                messagebox.showinfo("Información", "No hay datos registrados aún.")
                return
            
            # Intentamos cargar el archivo JSON
            with open(archivo_json, 'r', encoding='utf-8') as f:
                try:
                    datos = json.load(f)
                    # Verificamos que sea una lista
                    if not isinstance(datos, list):
                        raise ValueError("El archivo de datos no es una lista de árboles.")
                    self.datos = datos
                except (json.JSONDecodeError, ValueError):
                    messagebox.showerror("Error", "El archivo de datos está corrupto o no es válido.")
                    self.datos = []  # Si falla, inicializamos vacío

            # Mostrar todos los datos inicialmente
            self.mostrar_resultados(self.datos)
            
        except Exception as e:
            messagebox.showerror("Error", f"No se pudieron cargar los datos: {str(e)}")
            self.datos = []  # En caso de error, lista vacía


    def mostrar_resultados(self, arboles):
        # Limpiar resultados anteriores
        
        for widget in self.frame_resultados.winfo_children():
            widget.destroy()
        
        if not arboles:
            ttk.Label(
                self.frame_resultados, 
                text="No se encontraron árboles", 
                style="Filtros.TLabel"
            ).pack()
            return
        
        for arbol in arboles:
            # Crear frame para cada árbol con imagen de fondo
            frame_arbol = tk.Frame(
                self.frame_resultados, 
                width=400,
                height=300,
                bd=0,
                highlightthickness=0
            )
            frame_arbol.pack_propagate(False)  # Mantener tamaño fijo
            frame_arbol.pack(fill="x", pady=5, padx=5)
            
            # Configurar imagen de fondo si está disponible
            if self.fondo_arbol_tk:
                fondo_label = tk.Label(frame_arbol, image=self.fondo_arbol_tk)
                fondo_label.place(x=0, y=0, relwidth=1, relheight=1)
                fondo_label.image = self.fondo_arbol_tk  # Mantener referencia
            
            # Frame interno para el contenido (con márgenes)
            frame_contenido = tk.Frame(
                frame_arbol, 
                bg="white", 
                bd=0,
                padx=10,
                pady=10
            )
            frame_contenido.place(relx=0.5, rely=0.5, anchor="center", width=360, height=260)
            
            # Frame para la imagen (arriba)
            frame_imagen = tk.Frame(frame_contenido, bg="white", height=150)
            frame_imagen.pack(fill="x", pady=(0, 10))
            
            # Mostrar imagen si existe
            if arbol.get("imagen"):
                try:
                    directorio = os.path.dirname(os.path.abspath(__file__))
                    ruta_imagen = os.path.join(directorio, "imagenes_arboles", arbol["imagen"])
                    img = Image.open(ruta_imagen)
                    img.thumbnail((160, 160))
                    img_tk = ImageTk.PhotoImage(img)
                    
                    label_imagen = tk.Label(frame_imagen, image=img_tk, bg="white")
                    label_imagen.image = img_tk
                    label_imagen.pack()
                except Exception as e:
                    print(f"Error al cargar imagen: {e}")
                    ttk.Label(
                        frame_imagen, 
                        text="Imagen no disponible", 
                        style="Filtros.TLabel"
                    ).pack()
            else:
                ttk.Label(
                    frame_imagen, 
                    text="Imagen no disponible", 
                    style="Filtros.TLabel"
                ).pack()
            
            # Frame para el texto (abajo)
            frame_texto = tk.Frame(frame_contenido, bg="white")
            frame_texto.pack(fill="x")
            
            # Nombre del árbol centrado y en negrita
            tk.Label(
                frame_texto, 
                text=arbol.get("especie", "Desconocido"), 
                font=("Montserrat", 12, "bold"),
                foreground="#182C2B",
                bg="white",
                anchor="center"
            ).pack(fill="x", pady=(0, 5))
            
            # Edad (calculada)
            tk.Label(
                frame_texto, 
                text=f"Edad: {self.calcular_edad(arbol.get('fecha_plantacion', ''))}",
                font=("Montserrat", 9),
                foreground="#182C2B",
                bg="white",
                anchor="w"
            ).pack(fill="x")
            
            # Ubicación
            tk.Label(
                frame_texto, 
                text=f"Ubicación: {arbol.get('ubicacion', 'Desconocida')}",
                font=("Montserrat", 9),
                foreground="#182C2B",
                bg="white",
                anchor="w"
            ).pack(fill="x")
            
    def calcular_edad(self, fecha_plantacion):
        try:
            fecha_plant = datetime.strptime(fecha_plantacion, "%d/%m/%Y")
            hoy = datetime.now()
            diferencia = hoy - fecha_plant
            meses = diferencia.days // 30
            
            if meses == 0:
                semanas = diferencia.days // 7
                if semanas == 0:
                    return f"{diferencia.days} días"
                return f"{semanas} semanas"
            elif meses < 12:
                return f"{meses} meses"
            else:
                años = meses // 12
                meses_restantes = meses % 12
                if meses_restantes == 0:
                    return f"{años} años"
                return f"{años} años y {meses_restantes} meses"
        except:
            return "Desconocida"

    def filtrar_resultados(self):
        # Verificar que los datos estén correctamente cargados
        if not hasattr(self, 'datos') or not isinstance(self.datos, list):
            messagebox.showerror("Error", "Los datos no están cargados correctamente.")
            return

        # Obtener criterios de búsqueda (convertir a minúsculas y eliminar espacios)
        filtro_especie = self.entrada_especie.get().strip().lower()
        filtro_ubicacion = self.entrada_ubicacion.get().strip().lower()
        filtro_fecha = self.entrada_fecha.get().strip()

        # Validar que al menos un filtro tenga contenido
        if not any([filtro_especie, filtro_ubicacion, filtro_fecha]):
            messagebox.showwarning("Advertencia", "Ingrese al menos un criterio de búsqueda")
            return

        # Filtrar datos usando listas de comprensión (más eficiente)
        resultados = [
            arbol for arbol in self.datos
            if (not filtro_especie or filtro_especie in arbol.get("especie", "").lower()) and
            (not filtro_ubicacion or filtro_ubicacion in arbol.get("ubicacion", "").lower()) and
            (not filtro_fecha or filtro_fecha == arbol.get("fecha_plantacion", ""))
        ]

        # Mostrar resultados filtrados
        self.mostrar_resultados(resultados)


    def limpiar_filtros(self):
        self.entrada_especie.delete(0, tk.END)
        self.entrada_ubicacion.delete(0, tk.END)
        self.entrada_fecha.delete(0, tk.END)
        self.mostrar_resultados(self.datos)  # Mostrar todos los datos nuevamente
    
    def regresar_al_menu(self):
        self.raiz.destroy()
        nueva_ventana = tk.Tk()
        VentanaPrincipal(nueva_ventana)
        nueva_ventana.mainloop()

class VentanaReportes:
    def __init__(self, root):
        self.root = root
        self.root.title("Análisis Avanzado de Datos")
        self.root.geometry("1129x632")
        self.root.configure(bg="#FEF3E2")  
        self.root.resizable(False, False)
        self.root.iconbitmap("Interfaz//IconoAPP.ico")

        self.style = ttk.Style()
        self.style.theme_use('clam')
        self.configurar_estilos()

        ruta_imagen = "Interfaz//VentanaReportes//Analisisdedatos.png"

        if os.path.exists(ruta_imagen):
            try:
                imagen_original = Image.open(ruta_imagen)
                imagen_redimensionada = imagen_original.resize((1129, 90))  
                self.imagen_fondo = ImageTk.PhotoImage(imagen_redimensionada)

                self.label_imagen = tk.Label(
                    self.root,
                    image=self.imagen_fondo,
                    borderwidth=0
                )
                self.label_imagen.image = self.imagen_fondo  
                self.label_imagen.pack(fill="x", side="top")
            except Exception as e:
                print(f"❌ Error al abrir la imagen: {e}")
        else:
            print(f"⚠️ Imagen no encontrada en: {ruta_imagen}")
            self.label_imagen = tk.Label(
                self.root,
                text="Imagen no disponible",
                bg="white",
                fg="red",
                height=5
            )
            self.label_imagen.pack(fill="x", side="top")

        ruta_imagen_boton = "Interfaz//VentanaReportes//RegresarMenu.png"  
        if os.path.exists(ruta_imagen_boton):
            try:
                imagen_boton = Image.open(ruta_imagen_boton)
                self.imagen_boton_tk = ImageTk.PhotoImage(imagen_boton)

                self.boton_personalizado = tk.Button(
                    self.root,  
                    image=self.imagen_boton_tk,
                    borderwidth=0,
                    bg="#F1CBB6",
                    command=self.regresar_al_menu,
                )
                self.boton_personalizado.place(x=30, y=0)
            except Exception as e:
                print(f"❌ Error al cargar imagen del botón: {e}")
        else:
            print(f"⚠️ Imagen del botón no encontrada: {ruta_imagen_boton}")

        self.df = self.cargar_datos()

        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill="both", expand=True, padx=10, pady=10)

        self.tab1 = ttk.Frame(self.notebook)
        self.notebook.add(self.tab1, text="Distribución por Especie")
        self.crear_grafico_distribucion()

        self.tab2 = ttk.Frame(self.notebook)
        self.notebook.add(self.tab2, text="Tendencia de Plantaciones")
        self.crear_grafico_temporal()

    def configurar_estilos(self):
        """Configura todos los estilos visuales"""
        self.style.configure("TNotebook", background="#FEF3E2")
        self.style.configure("TNotebook.Tab", 
                           background="#FFE0B2",
                           foreground="#5D4037",
                           padding=[15, 5],
                           font=('Segoe UI', 10, 'bold'))
        self.style.map("TNotebook.Tab",
                      background=[("selected", "#FEF3E2")],
                      lightcolor=[("selected", "#FEF3E2")])
        
        self.style.configure("Treeview",
                           background="#FEF3E2",
                           fieldbackground="#FEF3E2",
                           foreground="#5D4037",
                           font=('Segoe UI', 9))
        self.style.configure("Treeview.Heading",
                           background="#FFE0B2",
                           foreground="#5D4037",
                           font=('Segoe UI', 10, 'bold'))
        self.style.map("Treeview",
                      background=[('selected', '#4CAF50')],
                      foreground=[('selected', 'white')])

    def cargar_datos(self):
        try:
            with open(os.path.join("Base_de_Datos", "arboles.json"), 'r', encoding='utf-8') as f:
                datos = json.load(f)
            df = pd.DataFrame(datos)
            df['fecha_plantacion'] = pd.to_datetime(df['fecha_plantacion'], dayfirst=True)
            return df
        except Exception as e:
            print(f"Error cargando datos: {e}")
            return pd.DataFrame()

    def crear_grafico_distribucion(self):
        if not self.df.empty:
            fig, ax = plt.subplots(figsize=(10, 5))
            
            fig.patch.set_facecolor('#FEF3E2')
            ax.set_facecolor('#FEF3E2')
            
            # Personalizar spines (bordes)
            for spine in ax.spines.values():
                spine.set_edgecolor('#5D4037')
                spine.set_linewidth(1.5)
            
            conteo = self.df['especie'].value_counts()
            bars = conteo.plot(kind='barh', ax=ax, color='#4CAF50', edgecolor='#388E3C')

            ax.set_title('Distribución de Árboles por Especie', 
                        pad=20, 
                        fontsize=14, 
                        fontweight='bold',
                        color='#5D4037')
            
            ax.set_xlabel('Cantidad', 
                         labelpad=10, 
                         fontsize=12, 
                         color='#5D4037')
            
            ax.tick_params(axis='both', colors='#5D4037')
            
            for bar in bars.patches:
                ax.text(bar.get_width() + 0.5,
                        bar.get_y() + bar.get_height()/2,
                        f'{int(bar.get_width())}',
                        va='center',
                        fontweight='bold',
                        color='#2E7D32')

            canvas = FigureCanvasTkAgg(fig, master=self.tab1)
            canvas.draw()
            canvas.get_tk_widget().pack(fill="both", expand=True, padx=10, pady=10)

    def crear_grafico_temporal(self):
        if not self.df.empty:
            # Frame principal
            main_frame = ttk.Frame(self.tab2)
            main_frame.pack(fill="both", expand=True)

            # Frame para el gráfico
            graph_frame = ttk.Frame(main_frame)
            graph_frame.pack(fill="x", padx=10, pady=(0, 10))

            fig, ax = plt.subplots(figsize=(10, 4))
            
            # Configurar fondo del gráfico
            fig.patch.set_facecolor('#FEF3E2')
            ax.set_facecolor('#FEF3E2')
            
            for spine in ax.spines.values():
                spine.set_edgecolor('#5D4037')
                spine.set_linewidth(1.5)

            df_anual = self.df.copy()
            df_anual['año'] = df_anual['fecha_plantacion'].dt.year
            anual_counts = df_anual['año'].value_counts().sort_index()

            # Gráfico de línea con puntos
            line = ax.plot(anual_counts.index, 
                         anual_counts.values, 
                         color='#4CAF50', 
                         linestyle='-', 
                         linewidth=2,
                         marker='o',
                         markersize=8,
                         markerfacecolor='#2E7D32',
                         markeredgecolor='#1B5E20')

            ax.set_title('Tendencia Anual de Plantaciones', 
                        pad=20, 
                        fontsize=14, 
                        fontweight='bold',
                        color='#5D4037')
            
            ax.set_xlabel('Año', 
                         labelpad=10, 
                         fontsize=12, 
                         color='#5D4037')
            
            ax.set_ylabel('Árboles plantados', 
                         labelpad=10, 
                         fontsize=12, 
                         color='#5D4037')
            
            ax.tick_params(axis='both', colors='#5D4037')
            ax.grid(True, linestyle=':', color='#BCAAA4', alpha=0.7)
            
            ax.set_xlim(anual_counts.index.min() - 0.5, anual_counts.index.max() + 0.5)
            ax.set_ylim(0, anual_counts.values.max() * 1.1)
            
            for x, y in zip(anual_counts.index, anual_counts.values):
                ax.text(x, y + (anual_counts.values.max() * 0.03),
                        f'{y}',
                        ha='center',
                        fontweight='bold',
                        color='#2E7D32')

            plt.tight_layout()
            canvas = FigureCanvasTkAgg(fig, master=graph_frame)
            canvas.draw()
            canvas.get_tk_widget().pack(fill="x")

            # Frame para el árbol con scrollbar
            tree_frame = ttk.Frame(main_frame)
            tree_frame.pack(fill="both", expand=True, padx=10, pady=(0, 10))

            scrollbar = ttk.Scrollbar(tree_frame)
            scrollbar.pack(side="right", fill="y")

            tree = ttk.Treeview(
                tree_frame,
                yscrollcommand=scrollbar.set,
                height=10,
                columns=('Especie', 'Ubicación', 'Fecha'),
                show='tree headings'
            )
        
            tree.pack(side="left", fill="both", expand=True)
            scrollbar.config(command=tree.yview)

            tree.heading('#0', text='Año')
            tree.heading('Especie', text='Especie')
            tree.heading('Ubicación', text='Ubicación')
            tree.heading('Fecha', text='Fecha')

            for año, grupo in df_anual.groupby('año'):
                año_node = tree.insert('', 'end', text=str(año), values=('', '', ''))
                for _, fila in grupo.iterrows():
                    tree.insert(
                        año_node, 
                        'end', 
                        text='',
                        values=(
                            fila.get('especie', 'Desconocida'),
                            fila.get('ubicacion', 'Sin ubicación'),
                            fila['fecha_plantacion'].strftime("%d/%m/%Y")
                        )
                    )

    def regresar_al_menu(self):
        self.root.destroy()  # Cambiado de self.raiz a self.root
        nueva_ventana = tk.Tk()  
        VentanaPrincipal(nueva_ventana)  
        nueva_ventana.mainloop()

class VentanaAnalisisDatos:
    def __init__(self, raiz):
        self.raiz = raiz
        self.raiz.title("Análisis de Datos")
        self.raiz.configure(bg="#fef3e2")
        self.raiz.iconbitmap("Interfaz//IconoAPP.ico")
        # Tamaño ventana
        ancho_ventana = 1129
        alto_ventana = 632
        ancho_pantalla = self.raiz.winfo_screenwidth()
        alto_pantalla = self.raiz.winfo_screenheight()
        pos_x = int((ancho_pantalla - ancho_ventana) / 2)
        pos_y = int((alto_pantalla - alto_ventana) / 2)
        self.raiz.geometry(f"{ancho_ventana}x{alto_ventana}+{pos_x}+{pos_y}")
        self.raiz.resizable(0, 0)

        # Variables
        self.total_arboles = 0
        self.total_co2 = 0


        # Ruta de imagen
        ruta_imagen = "Interfaz//VentanaAnalisisDatos//Interfaz.png"
        if os.path.exists(ruta_imagen):
            imagen = Image.open(ruta_imagen)
            imagen = imagen.resize((ancho_ventana, alto_ventana))
            self.imagen_tk = ImageTk.PhotoImage(imagen)

            # Imagen de fondo
            self.label_fondo = tk.Label(self.raiz, image=self.imagen_tk)
            self.label_fondo.place(x=0, y=0, relwidth=1, relheight=1)
        else:
            print("❌ Imagen no encontrada:", os.path.abspath(ruta_imagen))

        #Boton de agregar descuento
        self.agregar=imagen=Image.open("Interfaz//VentanaAnalisisDatos//Regresar menu.png")
        self.agregar=ImageTk.PhotoImage(self.agregar)

        self.label_agregar=tk.Label(self.raiz,image=self.agregar,bg="#f1cbb6",cursor="hand2")
        self.label_agregar.place(x=11,y=30)
        self.label_agregar.bind("<Button-1>", lambda e: self.regresar_al_menu())

        self.mostrar_top_especies_con_scroll()
        self.mostrar_ubicacion_mas_reforestada()
        self.setup_co2_displays()
        self.calcular_datos_ambientales()

    def setup_co2_displays(self):
        # Número de árboles 
        self.lbl_arboles = tk.Label(self.raiz, text="0", bg="#fef3e2", font=("Arial", 20,"bold"))
        self.lbl_arboles.place(x=1005, y=510, anchor="center")
        
        # CO₂ absorbido 
        self.lbl_co2_1 = tk.Label(self.raiz, text="0", bg="#fef3e2", font=("Arial", 20,"bold"))
        self.lbl_co2_1.place(x=687, y=510, anchor="center")
        
        # CO₂ absorbido 
        self.lbl_co2_2 = tk.Label(self.raiz, text="0", bg="#fef3e2", font=("Arial", 18,"bold"))
        self.lbl_co2_2.place(x=1005, y=555, anchor="center")

    def calcular_datos_ambientales(self):
        try:
            # Cargar datos del archivo JSON
            with open(os.path.join("Base_de_Datos", "arboles.json"), 'r', encoding='utf-8') as f:
                datos = json.load(f)
            
            # Calcular totales
            self.total_arboles = len(datos)
            self.total_co2 = self.total_arboles * 30  # 30 kg por árbol por año
            
            # Actualizar las etiquetas
            self.lbl_arboles.config(text=str(self.total_arboles))
            self.lbl_co2_1.config(text=str(self.total_co2))
            self.lbl_co2_2.config(text=str(self.total_co2))
            
        except Exception as e:
            print(f"Error al calcular datos ambientales: {str(e)}")
            self.lbl_arboles.config(text="Error")
            self.lbl_co2_1.config(text="Error")
            self.lbl_co2_2.config(text="Error")

    def mostrar_ubicacion_mas_reforestada(self):
        try:
            with open("Base_de_Datos//arboles.json", "r", encoding="utf-8") as file:
                datos = json.load(file)

            if not datos:
                return

            # Agrupar por ubicación
            ubicaciones = {}
            for item in datos:
                ubicacion = item['ubicacion']
                ubicaciones.setdefault(ubicacion, []).append(item)

            ubicaciones_ordenadas = sorted(ubicaciones.items(), key=lambda x: len(x[1]), reverse=True)

            # Recuadro contenedor
            frame_tabla = tk.Frame(self.raiz, width=508, height=171, bg="#fef3e2")
            frame_tabla.place(x=570, y=188)
            frame_tabla.pack_propagate(False)

            # Scroll canvas
            canvas = tk.Canvas(frame_tabla, bg="#fef3e2", highlightthickness=0)
            scrollbar = tk.Scrollbar(frame_tabla, orient="vertical", command=canvas.yview)
            scroll_frame = tk.Frame(canvas, bg="#fef3e2")
            canvas.create_window((0, 0), window=scroll_frame, anchor="nw")
            canvas.configure(yscrollcommand=scrollbar.set)
            canvas.pack(side="left", fill="both", expand=True)
            scrollbar.pack(side="right", fill="y")

            def on_configure(event):
                canvas.configure(scrollregion=canvas.bbox("all"))

            scroll_frame.bind("<Configure>", on_configure)

            # Encabezado simple
            encabezado = tk.Frame(scroll_frame, bg="#fef3e2")
            encabezado.pack(fill=tk.X, pady=(0, 5))
            fuente = ("Courier New", 10, "bold")
            tk.Label(encabezado, text="#", width=3, font=fuente, bg="#fef3e2").pack(side=tk.LEFT)
            tk.Label(encabezado, text="Ubicación", width=28, font=fuente, bg="#fef3e2").pack(side=tk.LEFT)
            tk.Label(encabezado, text="Cantidad", width=10, font=fuente, bg="#fef3e2").pack(side=tk.LEFT)
            tk.Label(encabezado, text="Árboles 🌳", width=10, font=fuente, bg="#fef3e2").pack(side=tk.LEFT)

            # Mostrar filas
            for i, (ubicacion, arboles) in enumerate(ubicaciones_ordenadas[:10]):
                contenedor_fila = tk.Frame(scroll_frame, bg="#fef3e2")
                contenedor_fila.pack(fill=tk.X, pady=2)

                fila = tk.Frame(contenedor_fila, bg="#fef3e2")
                fila.pack(fill=tk.X)

                tk.Label(fila, text=str(i + 1), width=3, font=("Courier New", 10), bg="#fef3e2").pack(side=tk.LEFT)
                tk.Label(fila, text=ubicacion[:30] + "..." if len(ubicacion) > 33 else ubicacion,
                        width=28, anchor="w", font=("Courier New", 10), bg="#fef3e2").pack(side=tk.LEFT)
                tk.Label(fila, text=str(len(arboles)), width=10, font=("Courier New", 10), bg="#fef3e2").pack(side=tk.LEFT)

                btn = tk.Button(fila, text="Ver árboles 🌳", width=12, font=("Courier New", 9), bg="#e8dbc9", relief="flat", cursor="hand2")
                btn.pack(side=tk.LEFT)

                # Detalle oculto dentro del mismo contenedor
                detalles = tk.Frame(contenedor_fila, bg="#fef3e2")
                for arb in arboles:
                    especie = arb.get("especie", "")
                    fecha = arb.get("fecha_plantacion", "")
                    texto = f"• {especie} ({fecha})"
                    tk.Label(detalles, text=texto, font=("Courier New", 9), bg="#fef3e2", anchor="w").pack(anchor="w", padx=40)

                detalles.pack_forget()

                # Acción de desplegar
                def toggle_detalles(frame=detalles, boton=btn):
                    if frame.winfo_ismapped():
                        frame.pack_forget()
                        boton.config(text="Ver árboles 🌳")
                    else:
                        frame.pack(fill=tk.X)
                        boton.config(text="Ocultar 🌲")

                btn.config(command=toggle_detalles)

        except Exception as e:
            print("❌ Error al mostrar ubicación más reforestada:", str(e))


        
    def mostrar_top_especies_con_scroll(self):
        try:
            with open("Base_de_Datos//arboles.json", "r", encoding="utf-8") as file:
                datos = json.load(file)

            if not datos:
                return

            # Contar especies
            conteo = {}
            imagenes_por_especie = {}
            for item in datos:
                especie = item['especie']
                conteo[especie] = conteo.get(especie, 0) + 1
                if especie not in imagenes_por_especie:
                    imagenes_por_especie[especie] = item['imagen']

            especies_ordenadas = sorted(conteo.items(), key=lambda x: x[1], reverse=True)

            # Scroll canvas
            canvas = tk.Canvas(self.raiz, bg="#F1CBB6", highlightthickness=0, bd=0)
            scrollbar = tk.Scrollbar(self.raiz, orient="vertical", command=canvas.yview)
            scroll_frame = tk.Frame(canvas, bg="#F1CBB6")

            canvas.create_window((0, 0), window=scroll_frame, anchor="nw")
            canvas.configure(yscrollcommand=scrollbar.set)

            canvas.place(x=25, y=190, width=486, height=420)
            scrollbar.place(x=503, y=190, height=420)

            def configurar_scroll(event):
                canvas.configure(scrollregion=canvas.bbox("all"))

            scroll_frame.bind("<Configure>", configurar_scroll)

            # Para mantener referencias a imágenes
            self.imagenes_tk = []

            for i, (especie, cantidad) in enumerate(especies_ordenadas):
                imagen_nombre = imagenes_por_especie.get(especie)
                ruta_imagen = os.path.join("imagenes_arboles", imagen_nombre)  

                # Recuadro
                recuadro = tk.Frame(scroll_frame,width=369, height=160)
                recuadro.pack(pady=10)
                recuadro.pack_propagate(False)

                ruta_fondo = "Interfaz//VentanaAnalisisDatos//Rectangle 7.png"
                fondo_img = Image.open(ruta_fondo).resize((369, 160))
                fondo_tk = ImageTk.PhotoImage(fondo_img)
                self.imagenes_tk.append(fondo_tk)  # Guardar referencia

                fondo_label = tk.Label(recuadro, image=fondo_tk,bg="#F1CBB6")
                fondo_label.place(x=0, y=0, relwidth=1, relheight=1)
                
                # Imagen
                if os.path.exists(ruta_imagen):
                    imagen = Image.open(ruta_imagen).resize((129, 158))
                    imagen_tk = ImageTk.PhotoImage(imagen)
                    self.imagenes_tk.append(imagen_tk)

                    label_img = tk.Label(recuadro, image=imagen_tk, bg="white")
                    label_img.place(x=14, y=1)
                else:
                    print(f"⚠️ Imagen no encontrada: {ruta_imagen}")

                # Texto
                fuente = ('Courier New', 16, 'bold')
                tk.Label(recuadro, text=f"Ranking #{i + 1}", font=fuente, bg="#fef3e2").place(x=160, y=20)
                tk.Label(recuadro, text=f"{especie}", font=fuente, bg="#fef3e2").place(x=160, y=60)
                tk.Label(recuadro, text=f"Cantidad: {cantidad}", font=fuente, bg="#fef3e2").place(x=160, y=100)

        except Exception as e:
            print("❌ Error al mostrar especies:", str(e))
    
    def regresar_al_menu(self):
        self.raiz.destroy()
        nueva_ventana = tk.Tk()
        VentanaPrincipal(nueva_ventana)
        nueva_ventana.mainloop()

class VentanaGuiaCampo:
    def __init__(self, raiz):
        self.raiz = raiz
        self.raiz.title("Guía de Campo - Catálogo de Árboles")
        self.raiz.configure(bg="#FCF7F4")
        self.raiz.iconbitmap("Interfaz//IconoAPP.ico")

        ancho_ventana = 565
        alto_ventana = 690

        # Obtener el tamaño de la pantalla
        ancho_pantalla = self.raiz.winfo_screenwidth()
        alto_pantalla = self.raiz.winfo_screenheight()

        # Calcular la posición centrada
        pos_x = int((ancho_pantalla - ancho_ventana) / 2)
        pos_y = int((alto_pantalla - alto_ventana) / 2)

        # Establecer la geometría de la ventana con la posición centrada
        self.raiz.geometry(f"{ancho_ventana}x{alto_ventana}+{pos_x}+{pos_y}")

        # No se puede redimensionar la ventana
        self.raiz.resizable(0, 0)

        # Configurar estilo
        estilo = ttk.Style()
        estilo.theme_use('clam')
        estilo.configure("TFrame", background="#FCF7F4")
        estilo.configure("TLabel", background="#FCF7F4", font=("Arial", 10))
        
        # Frame superior solo para el botón de regresar (alineado a la izquierda)
        frame_boton_regresar = ttk.Frame(raiz, height=40, style="TLabel")
        frame_boton_regresar.pack(fill="x", padx=10, pady=(10, 0))
        
        # Botón de Regresar al Menú
        self.boton_regresar = tk.Button(
            frame_boton_regresar,
            text="<   Regresar",
            bg="#FCF7F4",
            fg="#577F67",
            command=self.regresar_al_menu,
            borderwidth=0,
            highlightthickness=0,
            font=("Montserrat", 12)
        )
        self.boton_regresar.pack(side="left", padx=5, pady=(10))
        
        # Frame separado para el título (centrado)
        frame_titulo = ttk.Frame(raiz, height=60, style="TLabel")
        frame_titulo.pack(fill="x", padx=10, pady=(0, 10))
        
        # Título de la ventana
        ttk.Label(
            frame_titulo,
            text="Árboles",
            font=("Montserrat", 14, "bold"),
            foreground="#182C2B",
            background="#FCF7F4"
        ).pack(expand=True)
        
        # Frame principal con scroll
        main_frame = ttk.Frame(raiz)
        main_frame.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        
        # Canvas y scrollbar
        canvas = tk.Canvas(main_frame, bg="#FCF7F4", highlightthickness=0)
        scrollbar = ttk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas, style="TFrame")
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(
                scrollregion=canvas.bbox("all")
            )
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        # Crear estructura de dos columnas
        self.columna_izq = ttk.Frame(scrollable_frame, style="TFrame")
        self.columna_izq.grid(row=0, column=0, padx=5, pady=5, sticky="nsew")
        
        self.columna_der = ttk.Frame(scrollable_frame, style="TFrame")
        self.columna_der.grid(row=0, column=1, padx=5, pady=5, sticky="nsew")
        
        scrollable_frame.grid_columnconfigure(0, weight=1)
        scrollable_frame.grid_columnconfigure(1, weight=1)
        
        # Cargar imagen de fondo para los frames de árboles
        try:
            self.fondo_arbol_img = Image.open("Interfaz//VentanaGuiaCampo//fondoguia.png")
            self.fondo_arbol_img = self.fondo_arbol_img.resize((250, 360), Image.LANCZOS)  # Tamaño aumentado para uniformidad
            self.fondo_arbol_tk = ImageTk.PhotoImage(self.fondo_arbol_img)
        except Exception as e:
            print(f"Error al cargar imagen de fondo: {e}")
            self.fondo_arbol_tk = None
        
        # Cargar datos del catálogo
        self.cargar_catalogo()
    
    def crear_frame_arbol(self, parent, arbol):
        """Crea un frame para un árbol con tamaño fijo"""
        # Frame principal con tamaño fijo
        frame_arbol = tk.Frame(
            parent, 
            bd=0, 
            highlightthickness=0,
            width=250,  # Ancho fijo
            height=310  # Alto fijo
        )
        frame_arbol.pack_propagate(False)  # Evita que el frame cambie de tamaño
        
        # Configurar imagen de fondo si está disponible
        if self.fondo_arbol_tk:
            fondo_label = tk.Label(frame_arbol, image=self.fondo_arbol_tk)
            fondo_label.place(x=0, y=0, relwidth=1, relheight=1)
            fondo_label.image = self.fondo_arbol_tk  # Mantener referencia
        
        # Frame interno para el contenido (con márgenes)
        frame_contenido = tk.Frame(
            frame_arbol, 
            bg="white", 
            bd=0,
            padx=10,
            pady=10
        )
        frame_contenido.place(relx=0.5, rely=0.5, anchor="center", width=230, height=290)
        
        try:
            # Cargar imagen del árbol con tamaño fijo
            img = Image.open(arbol["imagen"])
            img.thumbnail((200, 180))  # Tamaño fijo para todas las imágenes
            img_tk = ImageTk.PhotoImage(img)
            
            label_imagen = tk.Label(frame_contenido, image=img_tk, bg="white")
            label_imagen.image = img_tk  # Mantener referencia
            label_imagen.pack(pady=(5, 10))
        except Exception as e:
            print(f"Error al cargar imagen: {e}")
            label_imagen = tk.Label(
                frame_contenido,
                text=f"Imagen no disponible\n{arbol['imagen']}",
                bg="white",
                fg="#777777",
                wraplength=150  # Ancho fijo para texto
            )
            label_imagen.pack(pady=(5, 10))
        
        # Nombre del árbol
        tk.Label(
            frame_contenido,
            text=arbol["nombre"],
            font=("Montserrat", 12, "bold"),
            fg="#182C2B",
            bg="white",
            wraplength=120  # Para que el texto no desborde
        ).pack()

        tk.Label(
            frame_contenido,
            text=arbol["nombre2"],
            font=("Helvetica", 10, "italic"),
            fg="#777777",
            bg="white",
            wraplength=380  
        ).pack()
        
        # Tamaño del árbol
        tk.Label(
            frame_contenido,
            text=f"Tamaño: {arbol['tamano']}",
            font=("Montserrat", 10),
            fg="#182C2B",
            bg="white",
            wraplength=380
        ).pack(pady=(0, 5))

        
        
        return frame_arbol
    
    def cargar_catalogo(self):
        # Datos de ejemplo - deberías reemplazarlos con tus 55 árboles
        catalogo_arboles = [
            {"nombre": "Roble australiano","nombre2": "(Grevillea robusta)", "tamano": "25 m", "imagen": "arboles//1.png"},
            {"nombre": "Jacaranda ","nombre2": "(Jacaranda mimosifolia)", "tamano": "20 m", "imagen": "arboles//2.png"},
            {"nombre": "Pirul","nombre2": "(Schinus molle)", "tamano": "15 m", "imagen": "arboles//3.png"},
            {"nombre": "Castaño de Indias","nombre2": "(Aesculus hippocastanum)", "tamano": "30 m", "imagen": "arboles//4.png"},
            {"nombre": "Pulpo","nombre2": "(Schefflera actinophylla)", "tamano": "8 m", "imagen": "arboles//5.png"},
            {"nombre": "Laurel de la India","nombre2": "(Ficus benjamina)", "tamano": "30 m", "imagen": "arboles//6.png"},
            {"nombre": "Olmo chino","nombre2": "(Ulmus parvifolia)", "tamano": "25 m", "imagen": "arboles//7.png"},
            {"nombre": "Aile","nombre2": "(Alnus acuminata)", "tamano": "25 m", "imagen": "arboles//8.png"},
            {"nombre": "Capulín ","nombre2": "(Prunus serotina)", "tamano": "20 m", "imagen": "arboles//9.png"},
            {"nombre": "Encino quiebra hacha","nombre2": "(Quercus rugosa)", "tamano": "20 m", "imagen": "arboles//10.png"},
            {"nombre": "Trueno","nombre2": "(Ligustrum lucidum)", "tamano": "8 m", "imagen": "arboles//11.png"},
            {"nombre": "Liquidámbar","nombre2": "(Liquidambar styraciflua)", "tamano": "40 m", "imagen": "arboles//12.png"},
            {"nombre": "Sicomoro","nombre2": "(Platanus × hybrida)", "tamano": "25 m", "imagen": "arboles//13.png"},
            {"nombre": "Pata de vaca","nombre2": "(Bauhinia variegata)", "tamano": "8 m", "imagen": "arboles//14.png"},
            {"nombre": "Higuera","nombre2": "(Ficus carica)", "tamano": "5 a 10 m", "imagen": "arboles//15.png"},
            {"nombre": "Dombeya","nombre2": "(Dombeya wallichii)", "tamano": "4 m", "imagen": "arboles//16.png"},
            {"nombre": "Álamo blanco","nombre2": "(Populus alba)", "tamano": "30 m", "imagen": "arboles//17.png"},
            {"nombre": "Álamo americano","nombre2": "(Populus deltoides)", "tamano": "20 m", "imagen": "arboles//18.png"},
            {"nombre": "Ginkgo","nombre2": "(Ginkgo biloba)", "tamano": "35 m", "imagen": "arboles//19.png"},
            {"nombre": "Macpalxóchitl","nombre2": "(Chiranthodendron pentadactylon)", "tamano": "30 m", "imagen": "arboles//20.png"},
            {"nombre": "Ayacahuite","nombre2": "(Pinus ayacahuite)", "tamano": "40 m", "imagen": "arboles//21.png"},
            {"nombre": "Pino llorón","nombre2": "(Pinus patula)", "tamano": "40 m", "imagen": "arboles//22.png"},
            {"nombre": "Pino de Monterrey","nombre2": "(Pinus radiata)", "tamano": "30 m", "imagen": "arboles//23.png"},
            {"nombre": "Pino piñonero","nombre2": "(Pinus cembroides )", "tamano": "15 m", "imagen": "arboles//24.png"},
            {"nombre": "Casuarina","nombre2": "(Casuarina equisetifolia)", "tamano": "40 m", "imagen": "arboles//25.png"},
            {"nombre": "Araucaria","nombre2": "(Araucaria heterophylla)", "tamano": "40 m", "imagen": "arboles//26.png"},
            {"nombre": "Cedro blanco","nombre2": "(Cupressus lusitanica)", "tamano": "30 m", "imagen": "arboles//27.png"},
            {"nombre": "Ciprés mediterráneo","nombre2": "(Cupressus sempervirens)", "tamano": "20 m", "imagen": "arboles//28.png"},
            {"nombre": "Tulia","nombre2": "(Platycladus orientalis)", "tamano": "4 m", "imagen": "arboles//29.png"},
            {"nombre": "Fresno","nombre2": "(Fraxinus uhdei)", "tamano": "30 m", "imagen": "arboles//30.png"},
            {"nombre": "Tulipán africano","nombre2": "(Spathodea campanulata)", "tamano": "25 m", "imagen": "arboles//31.png"},
            {"nombre": "Pimentero brasileño","nombre2": "(Schinus terebinthifolius)", "tamano": "10 m", "imagen": "arboles//32.png"},
            {"nombre": "Colorín","nombre2": "(Erythrina americana)", "tamano": "9 m", "imagen": "arboles//33.png"},
            {"nombre": "Retama","nombre2": "(Senna multiglandulosa)", "tamano": "4 m", "imagen": "arboles//34.png"},
            {"nombre": "Eucalipto rojo","nombre2": "(Eucalyptus camaldulensis)", "tamano": "50 m", "imagen": "arboles//35.png"},
            {"nombre": "Blue Gum","nombre2": "(Eucalyptus globulus)", "tamano": "50 m", "imagen": "arboles//36.png"},
            {"nombre": "Ahuehuete","nombre2": "(Taxodium mucronatum)", "tamano": "40 m", "imagen": "arboles//37.png"},
            {"nombre": "Escobillón rojo","nombre2": "(Callistemon citrinus)", "tamano": "10 m", "imagen": "arboles//38.png"},
            {"nombre": "Sauce llorón","nombre2": "(Salix babylonica)", "tamano": "5 a 12 m", "imagen": "arboles//39.png"},
            {"nombre": "Acacia plateada","nombre2": "(Acacia retinodes)", "tamano": "6 m", "imagen": "arboles//40.png"},
            {"nombre": "Tepoztán","nombre2": "(Buddleja cordata)", "tamano": "20 m", "imagen": "arboles//41.png"},
            {"nombre": "Hule","nombre2": "(Ficus elastica)", "tamano": "20 m", "imagen": "arboles//42.png"},
            {"nombre": "Árbol lira","nombre2": "(Ficus lyrata)", "tamano": "10 m", "imagen": "arboles//43.png"},
            {"nombre": "Magnolia","nombre2": "(Magnolia grandiflora)", "tamano": "15 m", "imagen": "arboles//44.png"},
            {"nombre": "Níspero","nombre2": "(Eriobotrya japonica)", "tamano": "8 m", "imagen": "arboles//45.png"},
            {"nombre": "Palma caribeña","nombre2": "(Roystonea regia)", "tamano": "30 m", "imagen": "arboles//46.png"},
            {"nombre": "Palma de abanico","nombre2": "(Washingtonia robusta)", "tamano": "25 m", "imagen": "arboles//47.png"},
            {"nombre": "Palma canaria","nombre2": "(Phoenix canariensis)", "tamano": "20 m", "imagen": "arboles//48.png"},
            {"nombre": "Izote","nombre2": "(Yucca elephantipes)", "tamano": "10 m", "imagen": "arboles//49.png"}
        ]
        
        # Alternar entre columnas
        col_actual = 0
        
        for i, arbol in enumerate(catalogo_arboles):
            # Determinar en qué columna colocar el árbol
            if col_actual == 0:
                frame_padre = self.columna_izq
            else:
                frame_padre = self.columna_der
            
            # Crear frame para el árbol con tamaño fijo
            frame_arbol = self.crear_frame_arbol(frame_padre, arbol)
            frame_arbol.pack(fill="x", pady=5, ipady=5)
            
            # Alternar columnas
            col_actual = 1 - col_actual  # Alterna entre 0 y 1
    
    
    def regresar_al_menu(self):
        self.raiz.destroy()
        nueva_ventana = tk.Tk()
        VentanaPrincipal(nueva_ventana)
        nueva_ventana.mainloop()

if __name__ == "__main__":
    raiz = tk.Tk()
    app = VentanaPrincipal(raiz)
    raiz.mainloop()